http://www.3delyvisions.com/skf1.htm

These files were downloaded from the above URL and were licensed as CC-BY 3.0 Unported on 2012/11/7
